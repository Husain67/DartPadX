# Simple Todo App (Flutter, Dart)

This is a minimal Todo app using Flutter and Dart. It stores todos locally using `shared_preferences`.

## How to use

1. Install Flutter: https://flutter.dev/docs/get-started/install
2. Create a new project:
   ```bash
   flutter create simple_todo_app