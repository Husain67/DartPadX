import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TodoApp());
}

class TodoItem {
  String id;
  String text;
  bool done;
  TodoItem({required this.id, required this.text, this.done = false});

  Map<String, dynamic> toJson() => {'id': id, 'text': text, 'done': done};
  static TodoItem fromJson(Map<String, dynamic> j) => TodoItem(
        id: j['id'] as String,
        text: j['text'] as String,
        done: j['done'] as bool,
      );
}

class TodoApp extends StatelessWidget {
  const TodoApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Simple Todo',
      theme: ThemeData(
        primarySwatch: Colors.teal,
      ),
      home: const TodoHomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class TodoHomePage extends StatefulWidget {
  const TodoHomePage({super.key});
  @override
  State<TodoHomePage> createState() => _TodoHomePageState();
}

class _TodoHomePageState extends State<TodoHomePage> {
  final _controller = TextEditingController();
  final List<TodoItem> _items = [];
  late SharedPreferences _prefs;
  static const String storageKey = 'simple_todo_items';

  @override
  void initState() {
    super.initState();
    _loadItems();
  }

  Future<void> _loadItems() async {
    _prefs = await SharedPreferences.getInstance();
    final raw = _prefs.getString(storageKey);
    if (raw != null) {
      try {
        final list = jsonDecode(raw) as List<dynamic>;
        _items.clear();
        for (var e in list) {
          _items.add(TodoItem.fromJson(Map<String, dynamic>.from(e)));
        }
        setState(() {});
      } catch (e) {
        // ignore parse errors and start fresh
      }
    }
  }

  Future<void> _saveItems() async {
    final raw = jsonEncode(_items.map((e) => e.toJson()).toList());
    await _prefs.setString(storageKey, raw);
  }

  void _addItem(String text) {
    if (text.trim().isEmpty) return;
    final item = TodoItem(id: DateTime.now().millisecondsSinceEpoch.toString(), text: text.trim());
    setState(() {
      _items.insert(0, item);
    });
    _controller.clear();
    _saveItems();
  }

  void _toggleDone(int index) {
    setState(() {
      _items[index].done = !_items[index].done;
    });
    _saveItems();
  }

  void _deleteItem(int index) {
    setState(() {
      _items.removeAt(index);
    });
    _saveItems();
  }

  void _editItem(int index) {
    final editController = TextEditingController(text: _items[index].text);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Edit Todo'),
        content: TextField(
          controller: editController,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Enter todo text'),
        ),
        actions: [
          TextButton(
            onPressed: () { Navigator.of(context).pop(); },
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              final newText = editController.text.trim();
              if (newText.isNotEmpty) {
                setState(() {
                  _items[index].text = newText;
                });
                _saveItems();
              }
              Navigator.of(context).pop();
            },
            child: const Text('Save'),
          )
        ],
      ),
    );
  }

  void _clearCompleted() {
    setState(() {
      _items.removeWhere((e) => e.done);
    });
    _saveItems();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Simple Todo'),
        actions: [
          IconButton(
            tooltip: 'Clear completed',
            icon: const Icon(Icons.delete_sweep),
            onPressed: _items.any((e) => e.done) ? _clearCompleted : null,
          )
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration(
                      hintText: 'Add a new todo',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    onSubmitted: _addItem,
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: () => _addItem(_controller.text),
                  child: const Text('Add'),
                )
              ],
            ),
          ),
          Expanded(
            child: _items.isEmpty
                ? const Center(child: Text('No todos yet — add one!'))
                : ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    itemCount: _items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, index) {
                      final item = _items[index];
                      return Dismissible(
                        key: Key(item.id),
                        background: Container(
                          color: Colors.redAccent,
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(right: 20),
                          child: const Icon(Icons.delete, color: Colors.white),
                        ),
                        direction: DismissDirection.endToStart,
                        onDismissed: (_) => _deleteItem(index),
                        child: Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          child: ListTile(
                            leading: Checkbox(
                              value: item.done,
                              onChanged: (_) => _toggleDone(index),
                            ),
                            title: Text(
                              item.text,
                              style: TextStyle(
                                decoration: item.done ? TextDecoration.lineThrough : TextDecoration.none,
                              ),
                            ),
                            trailing: IconButton(
                              icon: const Icon(Icons.edit),
                              onPressed: () => _editItem(index),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}